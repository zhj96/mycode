# -*- coding: utf-8 -*-
time_num = int(input())
student_num = int(input())
professor_num = int(input())
roast_list = []
student_score = 0
professor_score = 0
student_last_win_time = [-1]*student_num  # student last win time
professor_last_win_time = [-1]*professor_num  # professor last win time

for i in range(time_num):
    info = input()
    time, winner, _ = info.strip().split()
    winner_type = winner[0]
    winner_id = int(winner[1:])
    time = int(time)
    if winner_type == "s":  # student win
        if student_last_win_time[winner_id] != -1 and time - student_last_win_time[winner_id] <= 10:
            student_score += 1000
        else:
            student_score += 500
        student_last_win_time[winner_id] = time
    if winner_type == "p":  # professor win
        if professor_last_win_time[winner_id] != -1 and time - professor_last_win_time[winner_id] <= 10:
            professor_score += 1000
        else:
            professor_score += 500
        professor_last_win_time[winner_id] = time

print(str(student_score) + " " + str(professor_score))

