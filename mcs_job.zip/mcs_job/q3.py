# -*- coding: utf-8 -*-
all_extracts=["B", "C", "D", "G", "I", "S", "T"]
singleton_extracts = ["B", "G", "D"]
combination_extracts = ["I", "S", "C"]

mix_rules_source = [("B", "G"), ("B", "D"), ("D", "G"), ("I", "S"), ("C", "S"), ("C", "I")]  # initialize:"B"+"G" -> "S"
mix_rules_target = ["S", "I", "C", "B", "G", "D"]

#initialize
mix_to_result = {}
for i in range(len(all_extracts)):
    for j in range(i, len(all_extracts)):
        mix_to_result[(all_extracts[i], all_extracts[j])] = ""

for src, trg in mix_to_result.items():
    """generate mix rules"""
    first_type, second_type = src
    if first_type > second_type:  # first_type letter should small than second_type :: "C","B" -> "B","C"
        first_type, second_type = second_type, first_type
    assert (first_type, second_type) in mix_to_result
    mix_result = "T"
    if second_type == "T":
        mix_result = first_type

    if (first_type, second_type) in mix_rules_source:
        mix_result = mix_rules_target[mix_rules_source.index((first_type, second_type))]

    if first_type == second_type :
        mix_result = first_type

    mix_to_result[(first_type, second_type)] = mix_result


def mix_process(state):
    """process mix state"""
    if len(state) == 1:
        return state[0]

    while len(state) > 1:
        for i in range(len(state)-1):
            first_type, second_type = state[i] , state[i+1]
            if first_type > second_type:  # first_type letter should small than second_type :: "C","B" -> "B","C"
                first_type, second_type = second_type, first_type
            mix_result = mix_to_result[(first_type, second_type)]
            state[i] = mix_result
        del state[-1]
    return state[0]


inputs = str(input())
state = [i for i in inputs.strip()]  # list type
print(mix_process(state))