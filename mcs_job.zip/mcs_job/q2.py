# -*- coding: utf-8 -*-
def command1(M, x1, y1):
    M[x1-1][y1-1] += 1


def command2(M, x1, y1, x2, y2):
    glitter_num = 0
    for i in range(x1-1, x2):
        for j in range(y1-1, y2):
            glitter_num += M[i][j]
    return glitter_num


N, C = str(input()).strip().split()
N, C = int(N), int(C)
M = [[0]*N for _ in range(N)]  # initialize

all_glitter_num = 0  # final glitter_num
for i in range(C):
    inputs = str(input()).strip().split()
    inputs = [int(x) for x in inputs]
    if len(inputs) == 3:
        assert inputs[0] == 1
        id, x1, y1 = inputs
        command1(M, x1, y1)
    if len(inputs) == 5:
        assert inputs[0] == 2
        id, x1, y1, x2, y2 = inputs
        all_glitter_num += command2(M, x1, y1, x2, y2)

print(all_glitter_num)